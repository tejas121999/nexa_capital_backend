module.exports = {
    development: {
        host: "localhost",
        user: "root",
        password: "root",
        dialect: "mysql",
        database: "nexa_capital",
    }
}